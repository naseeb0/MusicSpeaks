var firebaseConfig = 
{
    apiKey: "AIzaSyCxkVXvWgLDwj0KKE75G1ij6FbounLyzeQ",
    authDomain: "eduquix.firebaseapp.com",
    databaseURL: "https://eduquix.firebaseio.com",
    projectId: "eduquix",
    storageBucket: "eduquix.appspot.com",
    messagingSenderId: "832543363823",
    appId: "1:832543363823:web:bbc9fd8f4936496d91c11a",
    measurementId: "G-7YSCXJRJ13"
  };
// Initialize Firebase
  firebase.initializeApp(firebaseConfig);